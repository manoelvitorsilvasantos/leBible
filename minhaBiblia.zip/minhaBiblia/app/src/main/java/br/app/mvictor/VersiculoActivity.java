package br.app.mvictor;



import android.content.*;
import android.graphics.*;
import android.os.*;
import android.speech.tts.*;
import android.support.v7.app.*;
import android.support.v7.appcompat.*;
import android.view.*;
import android.widget.*;
import br.app.mvictor.dao.*;
import br.app.mvictor.modelo.*;
import java.io.*;
import java.util.*;
import android.preference.*;

public class VersiculoActivity extends AppCompatActivity
{
	private BancoDeDados mBancoDeDados;
    private ListView lvCapitulo;
	private Button btnNext, btnBack;
    private List<Versiculo> listVersiculo = new ArrayList<Versiculo>();
    private ArrayAdapter<Versiculo> arrayAdapterVersiculo;
    private String capitulo = "1";
	private String livro = "1";
	private String nome = null;
	private TextToSpeech ts;
	Locale br = new Locale("pt-BR");
	private float velocidade = (float) 1.0;
	private float tom = (float) 1.0;
	private List<Versiculo> texto = new ArrayList<Versiculo>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verse);
		
	
		ts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener(){
				@Override
				public void onInit(int status)
				{
					// TODO: Implement this method
					if(status!=TextToSpeech.ERROR){
						ts.setLanguage(br);
					}
				}
			});
		
        inicializarComponentes();
        inicializarBancoDeDados();
        popularLista();
		
		
	     btnBack.setOnClickListener(new Button.OnClickListener(){
			 @Override
			 public void onClick(View v){
				 int chapter = Integer.parseInt(capitulo);
				 if(chapter != 1){
					 btnBack.setBackgroundColor(Color.GREEN);
					 btnBack.setTextColor(Color.BLACK);
					 popularListaBack();
				 }
				 else{
					 btnBack.setBackgroundColor(Color.RED);
					 btnBack.setTextColor(Color.BLACK);
				 }
				 
			 }
		 });
		 
		 
		btnNext.setOnClickListener(new Button.OnClickListener(){
				@Override
				public void onClick(View v){
					int chapter = Integer.parseInt(capitulo);
					if(chapter != getLastChapter()){
						btnNext.setBackgroundColor(Color.GREEN);
						btnNext.setTextColor(Color.BLACK);
						popularListaNext();
						//btnNext.setTextSize(24);
					}
					else{
						btnNext.setBackgroundColor(Color.RED);
						btnNext.setTextColor(Color.BLACK);
						//btnNext.setTextSize(24);
					}
				}
			});
    }

    private void inicializarComponentes() {
        lvCapitulo = findViewById(R.id.lvPessoa);
		btnNext = findViewById(R.id.btnNext);
		btnBack =findViewById(R.id.btnLast);
    }
	
	
	public int getLastChapter(){
		mBancoDeDados = new BancoDeDados(this);
		return mBancoDeDados.getLastChapter(this.livro);
	}
	
	public List<Versiculo> getLista(String livro, String capitulo){
		mBancoDeDados = new BancoDeDados(this);
		texto = mBancoDeDados.allVersiculo(livro, capitulo);
		return texto;
	}
	

    private void popularLista() {
		
        mBancoDeDados = new BancoDeDados(this);
		listVersiculo.clear();
		
		this.capitulo = getIntent().getStringExtra("capitulo");
		this.livro = getIntent().getStringExtra("livro");
		this.nome = getIntent().getStringExtra("nome").toUpperCase();
		ActionBar actionBar = getSupportActionBar();
		if(actionBar != null){
			actionBar.setTitle(this.nome.toUpperCase()+" - CAP: "+this.capitulo);
			actionBar.setDisplayHomeAsUpEnabled(true);
		}
	
		
        listVersiculo = mBancoDeDados.allVersiculo(this.livro, this.capitulo);
        arrayAdapterVersiculo = new ArrayAdapter<Versiculo>(this, R.layout.item_list2,listVersiculo);
        lvCapitulo.setAdapter(arrayAdapterVersiculo);
       
		lvCapitulo.setOnItemLongClickListener(new ListView.OnItemLongClickListener(){

				@Override
				public boolean onItemLongClick(AdapterView<?> p1, View view, int pos, long id)
				{
					// TODO: Implement this method
					String texto = lvCapitulo.getItemAtPosition(pos).toString();
					String book_name = nome;
					String chapter = capitulo;
					String verso = ""+(pos+1);
					String conteudo = book_name+" - "+chapter+":"+verso+"\n"+texto+"\n\n"+" LeBible";
					Intent sendIntent = new Intent();
					sendIntent.setAction(Intent.ACTION_SEND);
					sendIntent.putExtra(Intent.EXTRA_TEXT, conteudo);
					sendIntent.setType("text/plain");
					startActivity(Intent.createChooser(sendIntent, "Compartilhar versiculo"));
					//view.setBackgroundColor(Color.GREEN);
					return false;
				}

			
		});
		
		
		
		lvCapitulo.setOnItemClickListener(new ListView.OnItemClickListener(){

				@Override
				public void onItemClick(AdapterView<?> p1, View view, int pos, long id)
				{
					String texto = lvCapitulo.getItemAtPosition(pos).toString();
					String conteudo = "versiculo "+texto+"\n\n";
					falar(conteudo);
				}
		});
		
		
		lvCapitulo.setOnItemSelectedListener(new ListView.OnItemSelectedListener(){

				@Override
				public void onItemSelected(AdapterView<?> p1, View view, int p3, long p4)
				{
					// TODO: Implement this method
	
					
				}

				@Override
				public void onNothingSelected(AdapterView<?> p1)
				{
					// TODO: Implement this method
					
				}
				
			
		});
		
    }
	
	
	private void popularListaBack(){
		int cap = Integer.parseInt(capitulo);
		if(cap != 1){
			mBancoDeDados = new BancoDeDados(this);
			listVersiculo.clear();

			this.capitulo = String.valueOf((cap-1));
			this.livro = getIntent().getStringExtra("livro");
			this.nome = getIntent().getStringExtra("nome");
			ActionBar actionBar = getSupportActionBar();

			if(actionBar != null){
				actionBar.setTitle(this.nome.toUpperCase()+" - CAP: "+this.capitulo);
			}


			listVersiculo = mBancoDeDados.allVersiculo(this.livro, this.capitulo);
			arrayAdapterVersiculo = new ArrayAdapter<Versiculo>(this,R.layout.item_list2,listVersiculo);
			lvCapitulo.setAdapter(arrayAdapterVersiculo);

			lvCapitulo.setOnItemLongClickListener(new ListView.OnItemLongClickListener(){

					@Override
					public boolean onItemLongClick(AdapterView<?> p1, View view, int pos, long id)
					{
						// TODO: Implement this method
						String texto = lvCapitulo.getItemAtPosition(pos).toString();
						String book_name = nome;
						String chapter = capitulo;
						String verso = ""+(pos+1);
						String conteudo = book_name+" - "+chapter+":"+verso+"\n"+texto+"\n\n"+" LeBible";
						Intent sendIntent = new Intent();
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.putExtra(Intent.EXTRA_TEXT, conteudo);
						sendIntent.setType("text/plain");
						startActivity(Intent.createChooser(sendIntent, "Compartilhar versiculo"));

						return false;
					}


				});



			lvCapitulo.setOnItemClickListener(new ListView.OnItemClickListener(){

					@Override
					public void onItemClick(AdapterView<?> p1, View view, int pos, long id)
					{
						String texto = lvCapitulo.getItemAtPosition(pos).toString();
						String conteudo ="versiculo "+texto+"\n\n";
						falar(conteudo);
					}


				});
		}
	}
	
	private void popularListaNext(){
	int cap = Integer.parseInt(capitulo);
		if(cap != getLastChapter()){
		mBancoDeDados = new BancoDeDados(this);
			listVersiculo.clear();

			this.capitulo = String.valueOf((cap+1));
			this.livro = getIntent().getStringExtra("livro");
			this.nome = getIntent().getStringExtra("nome");
			ActionBar actionBar = getSupportActionBar();

			if(actionBar != null){
				actionBar.setTitle((this.nome.toUpperCase())+" - CAP: "+this.capitulo);
			}


			listVersiculo = mBancoDeDados.allVersiculo(this.livro, this.capitulo);
			arrayAdapterVersiculo = new ArrayAdapter<Versiculo>(this,R.layout.item_list2,listVersiculo);
			lvCapitulo.setAdapter(arrayAdapterVersiculo);

			lvCapitulo.setOnItemLongClickListener(new ListView.OnItemLongClickListener(){

					@Override
					public boolean onItemLongClick(AdapterView<?> p1, View view, int pos, long id)
					{
					// TODO: Implement this method
						String texto = lvCapitulo.getItemAtPosition(pos).toString();
						String book_name = nome;
						String chapter = capitulo;
						String verso = ""+(pos+1);
						String conteudo = book_name+" - "+chapter+":"+verso+"\n"+texto+"\n\n"+" LeBible";
						Intent sendIntent = new Intent();
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.putExtra(Intent.EXTRA_TEXT, conteudo);
						sendIntent.setType("text/plain");
						startActivity(Intent.createChooser(sendIntent, "Compartilhar versiculo"));

						return false;
						}


					});



			lvCapitulo.setOnItemClickListener(new ListView.OnItemClickListener(){

					@Override
					public void onItemClick(AdapterView<?> p1, View view, int pos, long id)
					{
						String texto = lvCapitulo.getItemAtPosition(pos).toString();
						String conteudo = "versiculo "+texto+"\n\n";
						falar(conteudo);
						}
					});
				}
		}
	
	

    private void inicializarBancoDeDados() {
        mBancoDeDados = new BancoDeDados(this);
        File database = getApplicationContext().getDatabasePath(BancoDeDados.NOMEDB);
        if (database.exists() == false){
            mBancoDeDados.getReadableDatabase();
            if (copiaBanco(this)){
                alert("Banco copiado com sucesso");
            }else{
                alert("Erro ao copiar o banco de dados");
            }
        }
    }

    private void alert(String s) {
        Toast.makeText(this,s,Toast.LENGTH_LONG).show();
    }

    private boolean copiaBanco(Context context) {
        try {
            InputStream inputStream = context.getAssets().open(BancoDeDados.NOMEDB);
            String outFile = BancoDeDados.LOCALDB + BancoDeDados.NOMEDB;
            OutputStream outputStream = new FileOutputStream(outFile);
            byte[] buff = new byte[1024];
            int legth = 0;
            while ((legth = inputStream.read(buff))>0){
                outputStream.write(buff,0,legth);
            }
            outputStream.flush();
            outputStream.close();
            return true;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

    }
	
	

	@Override
	protected void onDestroy()
	{
		if(ts!=null){
			ts.stop();
			ts.shutdown();
		}
		// TODO: Implement this method
		super.onDestroy();
	}
	/*
	public void onPause(){
		if(ts!=null){
			ts.stop();
			ts.shutdown();
		}
		super.onPause();
	}*/
	
	public void playVerse(View v){
	 
	  if(ts.isSpeaking()){
		  ts.stop();
	  }
	  
	  String it_book  =  this.livro;
	  String it_chapter = this.capitulo;
	  
	   Iterator <Versiculo> it = getLista(it_book, it_chapter).iterator();
	   Versiculo verso = null;
	   StringBuilder msg = new StringBuilder();
	   int cont = 1;
	   while(it.hasNext()){
		   verso = new Versiculo();
		   verso = it.next();
		   msg.append(verso.getTexto()+" ");
		   cont++;
	   }
	   
	   String original = msg.toString();
	   String saida = original.replace("<small>", "");
	   String saida2 = saida.replace("</small>", "");
	   String saida3 = saida2.replace("<i>", "");
	   String saidaFinal = saida3.replace("</i>", "");
	   
	   
		int count = saidaFinal.length();
		int max = 4000;
		int loopCount = count/max;

		for(int i = 0 ; i <= loopCount; i++ ) {
			if (i != loopCount) {
				ts.speak(saidaFinal.substring(i*max, (i+1)*max),ts.QUEUE_ADD, null);
			} else {
				int end = (count - ((i*max))+(i*max));
				ts.speak(saidaFinal.substring(i*max, end), TextToSpeech.QUEUE_ADD, null);
			}
		}
	}
	

	@Override
	protected void onRestart()
	{
		// TODO: Implement this method
		super.onRestart();
	}
	
	/*
	public boolean onOptionsItemSelected(MenuItem item){
		finishAffinity();
		Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
		startActivityForResult(myIntent, 0);
		return true;
	}*/

	@Override
	public void onBackPressed()
	{
		Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
		startActivityForResult(myIntent, 0);
		// TODO: Implement this method
		super.onBackPressed();
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_verso, menu);
		return true;
	}



	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                // User chose the "Settings" item, show the app settings UI...
				Intent settsIntent = new Intent(VersiculoActivity.this, Preference.class);
				startActivity(settsIntent);
                return true;

            case R.id.home:
                // User chose the "Favorite" action, mark the current item
                // as a favorite...
                return true;
			case R.id.action_back:
				Intent intent = new Intent(VersiculoActivity.this, AboutActivity.class);
				startActivity(intent);
				return true;
				

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }
    }
    
    private void falar(String conteudo){
		synchronized(this){
			if(ts.isSpeaking()){
				ts.stop();
			}
			SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(VersiculoActivity.this);
	        float vel = Float.parseFloat(prefs.getString("rate", "Default list prefs"));
			float tonalidade = Float.parseFloat(prefs.getString("pitch", "Default list prefs"));
			ts.setSpeechRate(vel);
			ts.setPitch(tonalidade);
			ts.speak(conteudo, TextToSpeech.QUEUE_FLUSH,null);
		}
	}

	
}
