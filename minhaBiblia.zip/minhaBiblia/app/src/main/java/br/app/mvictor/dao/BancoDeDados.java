package br.app.mvictor.dao;




/**
 * Created by Manoel Vitor on 26/01/22.
 */

import android.content.*;
import android.database.*;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import br.app.mvictor.modelo.*;
import java.util.*;

public class BancoDeDados extends SQLiteOpenHelper
 {
    public static final String NOMEDB = "biblia";
    public static final String LOCALDB = "/data/data/br.app.mvictor/databases/";
    private static final int VERSION = 1;
    private Context mContext;
    private SQLiteDatabase mSQSqLiteDatabase;


    public BancoDeDados(Context context) {
        super(context, NOMEDB, null, VERSION);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void openDataBase(){
        String dbPath = mContext.getDatabasePath(NOMEDB).getPath();
        if (mSQSqLiteDatabase != null && mSQSqLiteDatabase.isOpen()){
            return;
        }
        mSQSqLiteDatabase = SQLiteDatabase.openDatabase(dbPath,null, SQLiteDatabase.OPEN_READWRITE);
    }
	
	public int getLastChapter(String livro){
		openDataBase();
		int ultimo = 0;
		mSQSqLiteDatabase = this.getReadableDatabase();
		Cursor c = mSQSqLiteDatabase.rawQuery("SELECT DISTINCT * FROM versiculo WHERE id_livro = ? ORDER BY capitulo DESC LIMIT 1",new String[]{livro});
		if(c.moveToLast()){
			ultimo = c.getInt(c.getColumnIndex("capitulo"));
		}
		c.close();
		mSQSqLiteDatabase.close();
		return ultimo;
	}
	
	public List<Versiculo> allVersiculo(String livro, String capitulo){
		openDataBase();
        mSQSqLiteDatabase = this.getWritableDatabase();
        List<Versiculo> listVersiculo = new ArrayList<>();
        String sql = "SELECT DISTINCT id_livro, capitulo, numero,  texto FROM versiculo WHERE id_livro = ? AND capitulo = ?";
        Cursor cursor = mSQSqLiteDatabase.rawQuery(sql, new String[]{livro, capitulo});
        if (cursor.getCount()>0){
            if (cursor.moveToFirst()){
                do{
				    Versiculo v = new Versiculo();
					v.setId(cursor.getInt(cursor.getColumnIndex("id_livro")));
					v.setVersiculo(cursor.getInt(cursor.getColumnIndex("numero")));
					v.setTexto(cursor.getString(cursor.getColumnIndex("texto")));
					listVersiculo.add(v);

                }while(cursor.moveToNext());

            }
        }
        cursor.close();
        mSQSqLiteDatabase.close();
        return listVersiculo;
	}

	
	public List<Capitulo> allCapitulo(String idLivro){
		openDataBase();
        mSQSqLiteDatabase = this.getWritableDatabase();
        List<Capitulo> listCapitulo = new ArrayList<>();
        String sql = "SELECT DISTINCT id_livro, capitulo FROM versiculo WHERE id_livro = ?";
        Cursor cursor = mSQSqLiteDatabase.rawQuery(sql, new String[]{idLivro});
        if (cursor.getCount()>0){
            if (cursor.moveToFirst()){
                do{
				    Capitulo c = new Capitulo();
					c.setId(cursor.getInt(cursor.getColumnIndex("id_livro")));
					c.setCapitulo(cursor.getInt(cursor.getColumnIndex("capitulo")));
					listCapitulo.add(c);

                }while(cursor.moveToNext());

            }
        }
        cursor.close();
        mSQSqLiteDatabase.close();
        return listCapitulo;
	}

    public List<Livro> allLivro(){
        openDataBase();
        mSQSqLiteDatabase = this.getWritableDatabase();
        List<Livro> listLivro = new ArrayList<>();
        String sql = "SELECT * FROM livro ORDER BY ordem";
        Cursor cursor = mSQSqLiteDatabase.rawQuery(sql,null);
        if (cursor.getCount()>0){
            if (cursor.moveToFirst()){
                do{
					Livro l = new Livro();
					l.setId(cursor.getInt(cursor.getColumnIndex("_id")));
					l.setTitulo(cursor.getString(cursor.getColumnIndex("titulo")));
					listLivro.add(l);
					
                }while(cursor.moveToNext());
				
            }
        }
        cursor.close();
        mSQSqLiteDatabase.close();
        return listLivro;

    }

}
