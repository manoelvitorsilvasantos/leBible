package br.app.mvictor;
import android.support.v7.app.*;
import android.os.*;
import android.widget.*;
import android.text.*;
import android.content.*;
import android.view.*;
import android.text.method.*;

public class AboutActivity extends AppCompatActivity
{
	
	private TextView textView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.about);
		
		textView = findViewById(R.id.textView);
		textView.setPadding(8,10,8,10);
		textView.setText(Html.fromHtml(getResources().getString(R.string.html)));
		textView.setMovementMethod(LinkMovementMethod.getInstance());
		ActionBar actionBar = getSupportActionBar();
		if(actionBar!=null){
			actionBar.setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public void onBackPressed()
	{
		home();
		// TODO: Implement this method
		super.onBackPressed();
	}
	
	private void home(){
		Intent myIntent = new Intent(getApplicationContext(), MainActivity.class);
		startActivityForResult(myIntent, 0);
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		home();
		// TODO: Implement this method
		return super.onOptionsItemSelected(item);
	}  
}
