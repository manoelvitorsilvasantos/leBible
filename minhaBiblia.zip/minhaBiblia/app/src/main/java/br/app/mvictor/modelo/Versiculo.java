package br.app.mvictor.modelo;

import android.text.*;

public class Versiculo
{
	private int id;
	private int capitulo;
	private String texto;
	private int versiculo;

	public Versiculo(){

	}

	public void setCapitulo(int capitulo)
	{
		this.capitulo = capitulo;
	}

	public int getCapitulo()
	{
		return capitulo;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getId()
	{
		return id;
	}

	public void setTexto(String texto)
	{
		this.texto = texto;
	}

	public String getTexto()
	{
		return texto;
	}

	public void setVersiculo(int versiculo)
	{
		this.versiculo = versiculo;
	}

	public int getVersiculo()
	{
		return versiculo;
	}

	

	@Override
	public String toString(){
		return String.valueOf(versiculo+" "+Html.fromHtml(texto));
	}
	
	
}
