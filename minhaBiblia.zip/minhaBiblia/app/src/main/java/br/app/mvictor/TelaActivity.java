package br.app.mvictor;


import android.os.*;
import android.content.*;
import android.support.v7.app.*;

public class TelaActivity extends AppCompatActivity
{
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		
		Handler handler = new Handler();
		handler.postDelayed(new Runnable(){
			@Override
			public void run(){
				mostrar();
			}
		}, 2000);
		
	}
	
	private void mostrar(){
		Intent i = new Intent(TelaActivity.this, MainActivity.class);
		startActivity(i);
	}
	
}
