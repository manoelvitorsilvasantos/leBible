package br.app.mvictor;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import br.app.mvictor.dao.BancoDeDados;
import br.app.mvictor.modelo.Pessoa;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import br.app.mvictor.modelo.*;
import android.speech.tts.*;
import java.util.*;
import android.database.sqlite.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.support.v7.app.*;
import android.preference.*;

public class MainActivity extends AppCompatActivity {

    private BancoDeDados mBancoDeDados;
    private ListView lvLivro;
    private List<Livro> listLivro = new ArrayList<Livro>();
    private ArrayAdapter<Livro> arrayAdapterPessoa;
	private TextToSpeech ts;
	private Locale br = new Locale("pt-BR");
	private float velocidade = (float) 0.5;
	private float tom = (float) 1.0;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		ActionBar actionBar = getSupportActionBar();
		if(actionBar!=null){
			actionBar.setTitle(getResources().getString(R.string.app_name));
		}
		
		ts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener(){
				@Override
				public void onInit(int status)
				{
					// TODO: Implement this method
					if(status!=TextToSpeech.ERROR){
						ts.setLanguage(br);
					}
				}
			});
        inicializarComponentes();
        inicializarBancoDeDados();
        popularLista();
    }

    private void inicializarComponentes() {
        lvLivro = findViewById(R.id.lvPessoa);
    }

    private void popularLista() throws SQLiteException{
        mBancoDeDados = new BancoDeDados(this);
        listLivro.clear();
        listLivro = mBancoDeDados.allLivro();
        arrayAdapterPessoa = new ArrayAdapter<Livro>(this,R.layout.item_listview,listLivro);
        lvLivro.setAdapter(arrayAdapterPessoa);
		
		
		lvLivro.setOnItemClickListener(new ListView.OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> p1, View view, int pos, long id)
				{
					// TODO: Implement this method
					if(!(pos<0)){
						String livro = ""+(pos+1);
		                String nomeLivro = lvLivro.getItemAtPosition(pos).toString();
						Intent i = new Intent(getBaseContext(), CapituloActivity.class);
						i.putExtra("nome", nomeLivro.toUpperCase());
						i.putExtra("livro", livro);
						startActivity(i);
					}
				}
		});
    }

    private void inicializarBancoDeDados() {
        mBancoDeDados = new BancoDeDados(this);
        File database = getApplicationContext().getDatabasePath(BancoDeDados.NOMEDB);
        if (database.exists() == false){
            mBancoDeDados.getReadableDatabase();
            if (copiaBanco(this)){
                alert("Banco copiado com sucesso");
            }else{
                alert("Erro ao copiar o banco de dados");
            }
        }
    }

    private void alert(String s) {
		synchronized(this){
			Toast.makeText(this,s,Toast.LENGTH_LONG).show();
		}
    }

    private boolean copiaBanco(Context context) {
        try {
            InputStream inputStream = context.getAssets().open(BancoDeDados.NOMEDB);
            String outFile = BancoDeDados.LOCALDB + BancoDeDados.NOMEDB;
            OutputStream outputStream = new FileOutputStream(outFile);
            byte[] buff = new byte[1024];
            int legth = 0;
            while ((legth = inputStream.read(buff))>0){
                outputStream.write(buff,0,legth);
            }
            outputStream.flush();
            outputStream.close();
            return true;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
	
	
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_verso, menu);
		return true;
	}



	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                // User chose the "Settings" item, show the app settings UI...
				Intent settsIntent = new Intent(MainActivity.this, Preference.class);
				startActivity(settsIntent);
                return true;

            case R.id.home:
                // User chose the "Favorite" action, mark the current item
                // as a favorite...
                return true;
			case R.id.action_back:
				Intent intent = new Intent(MainActivity.this, AboutActivity.class);
				startActivity(intent);
				return true;


            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }
    }

	@Override
	public void onBackPressed()
	{
		this.finishAffinity();
		// TODO: Implement this method
		super.onBackPressed();
	}
	
	
}
