package br.app.mvictor;



import android.content.*;
import android.os.*;
import android.speech.tts.*;
import android.support.v7.app.*;
import android.view.*;
import android.widget.*;
import br.app.mvictor.dao.*;
import br.app.mvictor.modelo.*;
import java.io.*;
import java.util.*;

public class CapituloActivity extends AppCompatActivity
{
	private BancoDeDados mBancoDeDados;
    private ListView lvCapitulo;
    private List<Capitulo> listCapitulo = new ArrayList<Capitulo>();
    private ArrayAdapter<Capitulo> arrayAdapterCapitulo;
    private String livro;
	private String nomeLivro;
	private TextToSpeech ts;
	private Locale br = new Locale("pt-BR");
	private float velocidade = (float) 0.5;
	private float tom = (float) 1.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		ts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener(){
				@Override
				public void onInit(int status)
				{
					// TODO: Implement this method
					if(status!=TextToSpeech.ERROR){
						ts.setLanguage(br);
					}
				}
			});
        inicializarComponentes();
        inicializarBancoDeDados();
        popularLista();
    }

    private void inicializarComponentes() {
        lvCapitulo = findViewById(R.id.lvPessoa);
    }

    private void popularLista() {
        mBancoDeDados = new BancoDeDados(this);
        listCapitulo.clear();
		this.livro = getIntent().getStringExtra("livro");
		this.nomeLivro = getIntent().getStringExtra("nome");
		
		ActionBar ActionBar = getSupportActionBar();
		if(ActionBar!=null){
			String myBook = nomeLivro;
			ActionBar.setTitle(myBook.toUpperCase());
		}
		
        listCapitulo = mBancoDeDados.allCapitulo(this.livro);
        arrayAdapterCapitulo = new ArrayAdapter<Capitulo>(this,R.layout.item_listview,listCapitulo);
        lvCapitulo.setAdapter(arrayAdapterCapitulo);

		lvCapitulo.setOnItemClickListener(new ListView.OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
				{
					// TODO: Implement this method
					if(!(p3<0)){
						String capitulo = ""+(p3+1);
						falar("abrindo "+nomeLivro+" capítulo "+capitulo);
						Intent i = new Intent(getBaseContext(), VersiculoActivity.class);
						i.putExtra("livro", livro);
						i.putExtra("capitulo", capitulo);
						i.putExtra("nome", nomeLivro.toLowerCase());
						startActivity(i);
					}
				}
			});
    }

    private void inicializarBancoDeDados() {
        mBancoDeDados = new BancoDeDados(this);
        File database = getApplicationContext().getDatabasePath(BancoDeDados.NOMEDB);
        if (database.exists() == false){
            mBancoDeDados.getReadableDatabase();
            if (copiaBanco(this)){
                alert("Banco copiado com sucesso");
            }else{
                alert("Erro ao copiar o banco de dados");
            }
        }
    }

    private void alert(String s) {
        Toast.makeText(this,s,Toast.LENGTH_LONG).show();
    }

    private boolean copiaBanco(Context context) {
        try {
            InputStream inputStream = context.getAssets().open(BancoDeDados.NOMEDB);
            String outFile = BancoDeDados.LOCALDB + BancoDeDados.NOMEDB;
            OutputStream outputStream = new FileOutputStream(outFile);
            byte[] buff = new byte[1024];
            int legth = 0;
            while ((legth = inputStream.read(buff))>0){
                outputStream.write(buff,0,legth);
            }
            outputStream.flush();
            outputStream.close();
            return true;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

    }
	
	private void falar(String texto){
		ts.setSpeechRate(velocidade);
		ts.setPitch(tom);
		ts.speak(texto, TextToSpeech.QUEUE_FLUSH,null);
	}
	
	public void onPause(){
		if(ts!=null){
			ts.stop();
			ts.shutdown();
		}
		super.onPause();
	}
}
